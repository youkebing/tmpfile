--HZSB-DN15_200 by youkebing@163.com
--dev.read callback 参数1，ctx, 参数2 读到数据  参数3 读数据状态
--读基本参数  命令：
local dev = require("dev")
--local ext = require("ext")
local bytes = require("bytes")
--local xmath = require("xmath")

local datactx = {}

--任务组处理模块
local function taskGroup(data, cb, errcb)
	local nullFunc = function()
	end
	local o = {}
	local verrcb
	verrcb = (function(er)
		verrcb = nullFunc
		cb = nullFunc
		pcall(errcb, er)
	end)
	local tasks =  {}
	o.addUart = function(cmd, level, guid, d, on)
		local ccb;
		local oo = (function(_, s, st)
			xpcall(function()
				on(d, s, st)
				ccb()
			end, verrcb)
		end)
		table.insert(tasks, function(cc)
			ccb = cc
			dev.read(nil, level, guid, cmd, oo)
		end)
	end
	--par ：true 表示并行  flase 表示顺序执行
	o.start = function(par)
		local excute
		if par then
			local ii = 1
			local ccc = function()
				ii = ii - 1
				if ii == 0 then
					cb(data)
				end
			end
			excute = function()
				for i = 1, #tasks do
					ii = ii + 1
					tasks[i](ccc)
				end
				ccc()
			end
		else
			excute = (function()
				if (tasks[1] == nil) then
					cb(data)
				else
					local task = tasks[1];
					table.remove(tasks, 1)
					task(excute)
				end
			end)
		end
		xpcall(excute, verrcb)
	end
	return o
end

--生成mbrtu 请求数据帧
local function MkRtuCmd(cmd)
	local cc = string.char(tonumber(dev.addr())) .. cmd
	local ss = cc .. bytes.mbcrc(cc)
	print("MkRtuCmd ::::")
	print(bytes.tohex(ss))
	return ss
end
--校验rtu数据帧，错误抛出异常
--s 待校验数据 st 状态 p1 数据长度, p2 应答类型 errmsg 错误消息
local function RtuResponseChk(s, st, p1, p2, errmsg)
	--print("s:", s)
	--print("st", st)
	if st ~= 0 then
		error(s, 0)
	end
	local h = string.char(tonumber(dev.addr()), p2, p1 - 5)
	if string.len(s) ~= p1 or h ~= string.sub(s, 1, 3) then
		error(errmsg, 0)
	end
	if bytes.mbcrc(string.sub(s, 1, p1-2)) ~= string.sub(s, p1-1, p1) then
		error("数据CRC err!!", 0)
	end
end
--Tx:027-06 03 00 03 00 02 35 BC
--Rx:028-06 03 04 00 01 00 01 1C F3
local function ParsePtCtGetResponse(d, s, st)
	RtuResponseChk(s, st, 9, 03, "ParsePtCtGetResponse 读参数失败!!")
	--数据解析为大端模式
	local pt = bytes.de_u16(s, 3, false)
	local ct = bytes.de_u16(s, 5, false)
	if pt < 1 then
		pt = 1
	end
	if ct < 1 then
		ct = 1
	end
	d.pt = pt
	d.ct = ct
end
--总电量
local function ParseTotalGetResponse(d, s, st)
	RtuResponseChk(s, st, 9, 03, "ParseTotalGetResponse 读参数失败!!")
	local total = bytes.de_u32(s, 3, false)
	total = (total * d.pt * d.ct) / 1000
	d.total = total
end
--一般数据解析，数据错误抛出异常
--Tx: 06 03 00 23 00 0F F5 B3
--Rx: 06 03 1E 03 01 04 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 14 0A
local function ParseNormalGetResponse(d, s, st)
	RtuResponseChk(s, st, 35, 03, "ParseNormalGetResponse 读参数失败!!")
	--范围3-7
	local dpt = bytes.de_u8(s, 3)
	--范围1-5
	--local dct = bytes.de_u8(s, 4)
	--范围4-10
	--local dpq = bytes.de_u8(s, 5)
	--符号位 Q,Qc, Qb, Qa, P, Pc, Pb, Pa 0为正，1为负
	--local pqf = bytes.de_u8(s, 6)
	--A 相电压
	d.UA = bytes.de_u16(s, 7) * math.pow(10, dpt - 4)
	--B 相电压
	d.UB = bytes.de_u16(s, 9) * math.pow(10, dpt - 4)
	--C 相电压
	d.UC = bytes.de_u16(s, 11) * math.pow(10, dpt - 4)
	--UAB 线电压
	d.UAB = bytes.de_u16(s, 13) * math.pow(10, dpt - 4)
	--UBC 线电压
	d.UBC = bytes.de_u16(s, 15) * math.pow(10, dpt - 4)
	--UAC 线电压
	d.UAC = bytes.de_u16(s, 17) * math.pow(10, dpt - 4)
	--数据解析为大端模式
	--功率  4, 5
	--local gl = bytes.de_u16(s, 4, true)
	--总电量 6， 7， 8， 9
	--local zdl = bytes.de_u32(s, 6, true)
	--剩余电量 10,11,12,13
	--local sydl = bytes.de_u32(s, 9, false)
	--购电次数 14，15
	--local gdcs = bytes.de_u16(s, 13, false)
	--状态 16,17
	--local status = bytes.de_u16(s, 16, true)
	--购电次数本地保存一份
	--d.gdcs = gdcs
	--d.sydl = sydl
end

local function ReadStart(cnt, level)
	--o, cmd, level, guid, data, on
	cnt.addUart(MkRtuCmd("\x03\x00\x03\x00\x02"), level, "varget_1", datactx, ParsePtCtGetResponse)
	cnt.addUart(MkRtuCmd("\x03\x00\x3f\x00\x02"), level, "varget_2", datactx, ParseTotalGetResponse)
	cnt.addUart(MkRtuCmd("\x03\x00\x23\x00\x0f"), level, "varget_3", datactx, ParseNormalGetResponse)
	cnt.start(true)
end

--begin 定时上报数据
--读取定时上报数据标记
local ReadAutoFlag = false
--06 03 01 00 00 07 04 43    06 03 0E 00 00 00 00 00 00 00 00 00 00 00 00 00 00 5D 24
local function ReadAutoData()
	ReadAutoFlag = true
	local errcb = (function(e)
		if ReadAutoFlag then
			ReadAutoFlag = false
			print("------------------------------")
			print(debug)
			print(debug.traceback())
			print(e)
			local cc = {}
			cc.eid = 001
			cc.msg = e
			pcall(dev.repstatus, cc, nil)
		end
	end)
	local cb = function(_)
		if ReadAutoFlag then
			ReadAutoFlag = false
			local cc = {}
			cc["df"] = "e4kc"
			pcall(dev.repstatus, cc, datactx)
		end
	end
	local cnt = taskGroup(datactx, cb, errcb)
	ReadStart(cnt, 100)
end

local function RpcVarGet(_, on)
	local errcb = (function(e)
		print("------------------------------")
		print(debug)
		print(debug.traceback())
		print(e)
		local cc = {}
		cc.eid = 001
		cc.msg = e
		pcall(on, cc, nil)
	end)
	local cb = function(_)
		local cc = {}
		cc["df"] = "e4kc"
		pcall(on, cc, datactx)
	end
	local cnt = taskGroup(datactx, cb, errcb)
	ReadStart(cnt, 10)
end

--init lua system
(function()
	dev.regapi("poll", function()
		--print("poll  ceck!!!!!")
	end)
	dev.regapi("autoup", ReadAutoData)
	--RpcVarGet
	dev.regapi("varget", RpcVarGet)

	ReadAutoData()
end)()
