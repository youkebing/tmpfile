--HZSB-DN15_200 by youkebing@163.com

local dev = require("dev")
local bytes = require("bytes")

--全局数据块，存储表变量相关信息
--gdcs   充值次数
local datactx = {gdcs=0,test=122,}

--生成mbrtu 请求数据帧
function MkRtuCmd(cmd)
	local cc = string.char(tonumber(dev.addr())) .. cmd
	local ss = cc .. bytes.mbcrc(cc)
	print(bytes.tohex(ss))
	return ss
end
--校验rtu数据帧，错误抛出异常
--s 待校验数据 st 状态 p1 数据长度, p2 应答类型 errmsg 错误消息
function RtuResponseChk(s, st, p1, p2, errmsg)
	--print("s:", s)
	--print("st", st)
	if st ~= 0 then
		error(s, 0)
	end
	local h = string.char(tonumber(dev.addr()), p2, p1 - 5)
	if string.len(s) ~= p1 or h ~= string.sub(s, 1, 3) then
		error(errmsg, 0)
	end
	if bytes.mbcrc(string.sub(s, 1, p1-2)) ~= string.sub(s, p1-1, p1) then
		error("数据CRC err!!", 0)
	end
end
--一般数据解析，数据错误抛出异常
--req D1 03 01 00 00 07 16 64
--rep D1 03 0E 00 00 00 00 00 00 00 00 00 69 00 06 00 02 8F 25
function ParseNormalGetResponse(s, st)
	RtuResponseChk(s, st, 19, 03, "读参数失败!!")
	--数据解析为大端模式
	--功率  4, 5
	--local gl = bytes.de_u16(s, 4, true)
	--总电量 6， 7， 8， 9
	--local zdl = bytes.de_u32(s, 6, true)
	--剩余电量 10,11,12,13
	local sydl = bytes.de_u32(s, 9, false)
	--购电次数 14，15
	local gdcs = bytes.de_u16(s, 13, false)
	--状态 16,17
	--local status = bytes.de_u16(s, 16, true)
	--购电次数本地保存一份
	datactx.gdcs = gdcs
	datactx.sydl = sydl
end

function RpcVarGet(d, on, errh)
	local cmd = MkRtuCmd("\x03\x01\x00\x00\x07")
	local cb = function(ctx, s, st)
		xpcall(function()
			ParseNormalGetResponse(s, st)
			print("--------???-----------------");
			local cc = {}
			cc["df"] = "e4kcx"
			pcall(on, cc, datactx)
		end, errh)
	end
	dev.read(nil, 1, "varset x", cmd, cb)
end

function ChkReqAmountData(d)
	local msg = "预付费数据错误"
	local fy
	pcall(function()
		print(d)
		fy = d["fy"]
		if fy < 0 then
			msg = "充值金额不能为0!"
		else if fy > 1000 then
				msg = "充值金额不能大于1000!"
			else
				msg = ""
			end
		end
	end)
	if msg ~= "" then
		error(msg, 0)
	end
	return fy
end
--预付费电表充值
--请求集抄格式  ADD | 03 | 01 | 00 | 00 07 CRCH CRCL
--序号         0   | 1  | 2  | 3  |  4  5  6  7 8  9  10  11 12 13 14 15 16 17 18
--应答集抄格式  D1  | 03 | 0E | 00 | 00 00 00 00 00 00 00 00 69 00 06 00 02 8F 25
--回送         add | 03 | 0E |功率 |总电量	剩余电量	购电次数	状态	crch	crcl
--add	20	00	0F	00	03	06	新购金额	购电次数	crch	crcl
--req D1 20 00 0F 00 03 06 00 00 00 14 00 09 29 63
--rep D1 20 0A 00 00 00 A5 00 00 00 A5 00 09 BB B3
function RpcVarSet(d, on, errh)
	--获取预付费电量数据
	local fy = ChkReqAmountData(d)

	local addr = string.char(tonumber(dev.addr()))
	local gdcs
	local writeAmount = function()
		print("?????????????????????????????????///")
		local ss = "\x20\x00\x0f\x00\x03\x06" .. bytes.en_u32(fy, "", false) .. bytes.en_u16(gdcs, "", false)
		print(bytes.tohex(ss))
		ss = MkRtuCmd(ss)
		dev.read(nil, 1, "varset xw", ss, function(ctx, s, st)
			xpcall(function()
				RtuResponseChk(s, st, 15, 32, "充值失败!")
				--剩余金额 4,5,6,7
				local syje = bytes.de_u32(s, 3, false)
				--总购电金额 8,9,10,11
				local zgd = bytes.de_u32(s, 7, false)
				--购电次数 12，13
				local ngdcs = bytes.de_u16(s, 11, false)
				print(ngdcs)
				print(gdcs)
				if ngdcs ~= gdcs then
					error("充值失败！", 0)
				end
				datactx.gdcs = ngdcs
				on(nil, {syje=syje,zgd=zgd,gdcs=ngdcs, msg="充电成功!!"})
			end, errh)
		end)
	end

	local cmd = MkRtuCmd("\x03\x01\x00\x00\x07")
	local cb = function(ctx, s, st)
		xpcall(function()
			ParseNormalGetResponse(s, st)
			gdcs = datactx.gdcs + 1
			writeAmount()
		end, errh)
	end
	dev.read(nil, 1, "varset x", cmd, cb)
end

function SafeRpcCall(f, d, on)
	local errh = (function(e)
		print("------------------------------")
		print(debug)
		print(debug.traceback())
		print(e)
		local cc = {}
		cc.eid = 001
		cc.msg = e
		pcall(on, cc, nil)
	end)
	xpcall(function() f(d, on, errh) end, errh)
end

--begin 定时上报数据
--读取定时上报数据标记
local ReadAutoFlag = false
--读取定时上报数据
function ReadAutoData()
	ReadAutoFlag = true
	local errh = (function(e)
		if ReadAutoFlag then
			ReadAutoFlag = false
			print("------------------------------")
			print(debug)
			print(debug.traceback())
			print(e)
			local cc = {}
			cc.eid = 001
			cc.msg = e
			pcall(dev.repstatus, cc, nil)
		end
	end)

	local cmd = MkRtuCmd("\x03\x01\x00\x00\x07")
	local cb = function(ctx, s, st)
		xpcall(function()
			--print(s)
			--print(st)
			local cc = {}
			cc["df"] = "e4kcx"
			print("???HH____________________________")
			if ReadAutoFlag then
				ParseNormalGetResponse(s, st)
				print("--------???-----------------");
				pcall(dev.repstatus, cc, datactx)
				ReadAutoFlag = false
			end
		end, errh)
	end
	dev.read(nil, 100, "varset x__", cmd, cb)
end
--end 定时上报数据

--init lua system
(function()
	dev.regapi("poll", function()
		--print("poll  ceck!!!!!")
	end)
	dev.regapi("autoup", ReadAutoData)
	--RpcVarGet
	dev.regapi("varget", function(d, on)
		SafeRpcCall(RpcVarGet, d, on)
	end)
	--RpcVarSet
	dev.regapi("varset", function(d, on)
		SafeRpcCall(RpcVarSet, d, on)
	end)

	ReadAutoData()
end)()
