--HZSB-DN15_200 by youkebing@163.com
--dev.read callback 参数1，ctx, 参数2 读到数据  参数3 读数据状态
--读基本参数  命令：
local dev = require("dev")
--local ext = require("ext")
local bytes = require("bytes")
local xmath = require("xmath")

local datactx = {}

--任务组处理模块
local function taskGroup(cb, errcb)
	local nullFunc = function()
	end
	local o = {}
	local verrcb
	verrcb = (function(er)
		verrcb = nullFunc
		cb = nullFunc
		pcall(errcb, er)
	end)
	local tasks =  {}
	o.addUart = function(cmd, level, guid, d, on)
		local ccb;
		local oo = (function(_, s, st)
			xpcall(function()
				on(d, s, st)
				ccb()
			end, verrcb)
		end)
		table.insert(tasks, function(cc)
			ccb = cc
			dev.read(nil, level, guid, cmd, oo)
		end)
	end
	--par ：true 表示并行  flase 表示顺序执行
	o.start = function(par)
		local excute
		if par then
			local ii = 1
			local ccc = function()
				ii = ii - 1
				if ii == 0 then
					xpcall(cb, verrcb)
				end
			end
			excute = function()
				for i = 1, #tasks do
					ii = ii + 1
					tasks[i](ccc)
				end
				ccc()
			end
		else
			excute = (function()
				if (tasks[1] == nil) then
					xpcall(cb, verrcb)
				else
					local task = tasks[1];
					table.remove(tasks, 1)
					task(excute)
				end
			end)
		end
		xpcall(excute, verrcb)
	end
	return o
end

--校验rtu数据帧，错误抛出异常
--s 待校验数据 st 状态 p1 数据长度, p2 应答类型 errmsg 错误消息
local function MBRtuFrameChk(s, st, p1, p2, errh, errmsg)
	--print("s:", s)
	--print("st", st)
	if st ~= 0 then
		error(errh..s, 0)
	end
	local h = string.char(tonumber(dev.addr()), p2, p1 - 5)
	if string.len(s) ~= p1 or h ~= string.sub(s, 1, 3) then
		error(errh..errmsg, 0)
	end
	if bytes.mbcrc(string.sub(s, 1, p1-2)) ~= string.sub(s, p1-1, p1) then
		error(errh.."数据CRC err!!", 0)
	end
end
--Tx:027-06 03 00 03 00 02 35 BC
--Rx:028-06 03 04 00 01 00 01 1C F3
local function ParsePtCtGetResponse(d, s, st)
	MBRtuFrameChk(s, st, 9, 03, "读PT/CT", " 读参数失败!!")
	local ss = {string.byte(s, 1, -1)}
	--数据解析为大端模式
	local pt = (ss[4] * 256 + ss[5])
	local ct = (ss[6] * 256 + ss[7])
	if pt < 1 then
		pt = 1
	end
	if ct < 1 then
		ct = 1
	end
	d.PT = pt
	d.CT = ct
end
--总电量
local function ParseTotalGetResponse(d, s, st)
	MBRtuFrameChk(s, st, 9, 03, "读总电量: ", " 读参数失败!!")
	local ss = {string.byte(s, 1, -1)}
	d.Total = (ss[4] * 256 * 256 * 256 + ss[5] * 256 * 256 + ss[6] * 256 + ss[7])
end
--一般数据解析，数据错误抛出异常
--Tx:561-9B 03 00 61 00 06 89 EC
--Rx:562-9B 03 0C 00 00 00 00 09 0C 00 00 00 00 00 00 85 71
local function ParseNormalGetResponse(d, s, st)
	MBRtuFrameChk(s, st, 17, 03, "读电压电流: ", "读参数失败!!")
	local ss = {string.byte(s, 1, -1)}
	--A 相电压
	d.UA = ss[4] * 256 + ss[5]
	--B 相电压
	d.UB = ss[6] * 256 + ss[7]
	--C 相电压
	d.UC = ss[8] * 256 + ss[9]
	--UAB 线电压
	d.CA = ss[10] * 256 + ss[11]
	--UBC 线电压
	d.CB = ss[12] * 256 + ss[13]
	--UAC 线电压
	d.CC = ss[14] * 256 + ss[15]
end
--一般数据解析，数据错误抛出异常
--Tx:561-9B 03 00 61 00 06 89 EC
--Rx:562-9B 03 0C 00 00 00 00 09 0C 00 00 00 00 00 00 85 71
local function ParseNormalGetResponse2(d, s, st)
	MBRtuFrameChk(s, st, 13, 03, "读线电压: ", "读参数失败!!")
	local ss = {string.byte(s, 1, -1)}
	--频率
	d.Freq = ss[4] * 256 + ss[5]
	--A 相电压
	d.UAB = ss[6] * 256 + ss[7]
	--B 相电压
	d.UCB = ss[8] * 256 + ss[9]
	--C 相电压
	d.UAC = ss[10] * 256 + ss[11]
end
--生成mbrtu 请求数据帧
local function MkRtuCmd(cmd)
	local cc = string.char(tonumber(dev.addr())) .. cmd
	local ss = cc .. bytes.mbcrc(cc)
	print("MkRtuCmd ::::")
	print(bytes.tohex(ss))
	return ss
end
local function ReadStart(cnt, level)
	--o, cmd, level, guid, data, on
	cnt.addUart(MkRtuCmd("\x03\x00\x8d\x00\x02"), level, "varget_1", datactx, ParsePtCtGetResponse)
	cnt.addUart(MkRtuCmd("\x03\x00\x00\x00\x02"), level, "varget_2", datactx, ParseTotalGetResponse)
	cnt.addUart(MkRtuCmd("\x03\x00\x61\x00\x06"), level, "varget_3", datactx, ParseNormalGetResponse)
	cnt.addUart(MkRtuCmd("\x03\x00\x77\x00\x04"), level, "varget_4", datactx, ParseNormalGetResponse2)
	cnt.start(true)
end
local function calData()
	local o = {}
	--pt ct
	local pt = datactx.PT
	local ct = datactx.CT
	o.PT = pt
	o.CT = ct
	--total
	o.Total = xmath.ceil((datactx.Total * pt * ct) / 100, 2)
	--
	--A 相电压
	o.UA = xmath.ceil(datactx.UA * pt * 0.1, 2)
	--B 相电压
	o.UB = xmath.ceil(datactx.UB * pt * 0.1, 2)
	--C 相电压
	o.UC = xmath.ceil(datactx.UC * pt * 0.1, 2)
	--UAB 线电压
	o.CA = xmath.ceil(datactx.CA * ct * 0.1, 2)
	--UBC 线电压
	o.CB = xmath.ceil(datactx.CB * ct * 0.1, 2)
	--UAC 线电压
	o.CC = xmath.ceil(datactx.CC * ct * 0.1, 2)
	--
	o.Freq = xmath.ceil(datactx.Freq * 0.01, 2)
	--A 相电压
	o.UAB = xmath.ceil(datactx.UAB * pt * 0.1, 2)
	--B 相电压
	o.UCB = xmath.ceil(datactx.UCB * pt * 0.1, 2)
	--C 相电压
	o.UAC = xmath.ceil(datactx.UAC * pt * 0.1, 2)
	return o
end
--begin 定时上报数据
--读取定时上报数据标记
local ReadAutoFlag = false
--06 03 01 00 00 07 04 43    06 03 0E 00 00 00 00 00 00 00 00 00 00 00 00 00 00 5D 24
local function readAutoData()
	ReadAutoFlag = true
	local errcb = (function(e)
		if ReadAutoFlag then
			ReadAutoFlag = false
			print("------------------------------")
			print(debug)
			print(debug.traceback())
			print(e)
			local cc = {}
			cc.eid = 001
			cc.msg = e
			pcall(dev.repstatus, cc, nil)
		end
	end)
	local cb = function()
		if ReadAutoFlag then
			ReadAutoFlag = false
			local cc = {}
			cc["df"] = "dtsd1352"
			pcall(dev.repstatus, cc, calData())
		end
	end
	xpcall(function()
		local cnt = taskGroup(cb, errcb)
		ReadStart(cnt, 100)
	end, errcb)
end

local function rpcVarGet(_, on)
	local errcb = (function(e)
		print("------------------------------")
		print(debug)
		print(debug.traceback())
		print(e)
		local cc = {}
		cc.eid = 001
		cc.msg = e
		pcall(on, cc, nil)
	end)
	local cb = function()
		local cc = {}
		cc["df"] = "dtsd1352"
		pcall(on, cc, calData())
	end
	xpcall(function()
		local cnt = taskGroup(cb, errcb)
		ReadStart(cnt, 10)
	end, errcb)
end

--init lua system
(function()
	dev.regapi("poll", function()
		--print("poll  ceck!!!!!")
	end)
	dev.regapi("autoup", readAutoData)
	--RpcVarGet
	dev.regapi("varget", rpcVarGet)

	readAutoData()
end)()
