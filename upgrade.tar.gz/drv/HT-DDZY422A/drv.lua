--HZSB-DN15_200 by youkebing@163.com
--dev.read callback 参数1，ctx, 参数2 读到数据  参数3 读数据状态
--读基本参数  命令：
local dev = require("dev")
--local ext = require("ext")
local bytes = require("bytes")
local xmath = require("xmath")

local datactx = {}

--任务组处理模块
local function taskGroup(cb, errcb)
	local nullFunc = function()
	end
	local o = {}
	local verrcb
	verrcb = (function(er)
		verrcb = nullFunc
		cb = nullFunc
		pcall(errcb, er)
	end)
	local tasks =  {}
	o.addUart = function(cmd, level, guid, d, on)
		local ccb;
		local oo = (function(_, s, st)
			xpcall(function()
				on(d, s, st)
				ccb()
			end, verrcb)
		end)
		table.insert(tasks, function(cc)
			ccb = cc
			dev.read(nil, level, guid, cmd, oo)
		end)
	end
	--par ：true 表示并行  flase 表示顺序执行
	o.start = function(par)
		local excute
		if par then
			local ii = 1
			local ccc = function()
				ii = ii - 1
				if ii == 0 then
					xpcall(cb, verrcb)
				end
			end
			excute = function()
				for i = 1, #tasks do
					ii = ii + 1
					tasks[i](ccc)
				end
				ccc()
			end
		else
			excute = (function()
				if (tasks[1] == nil) then
					xpcall(cb, verrcb)
				else
					local task = tasks[1];
					table.remove(tasks, 1)
					task(excute)
				end
			end)
		end
		xpcall(excute, verrcb)
	end
	return o
end

--校验rtu数据帧，错误抛出异常  正常的返回处理后的数据帧
--s 待校验数据 st 状态 p1 数据长度, p2 应答类型 errmsg 错误消息
local function DLT645FrameChk(s, st, p1, p2, errh, errmsg)
	--print("s:", s)
	--print("st", st)
	local rr = bytes.tohex(s)
	if st ~= 0 then
		error(errh..s, 0)
	end
	local index = string.find(s, "\x68")
	if index <= 0 then
		error(errh.."(数据帧start错误"..rr..")", 0)
	end
	s = string.sub(s, index)
	--local ss = {string.byte(s, 1, -1)}
	if string.len(s) ~= p1 then
		error(errh.."(数据帧长度错误"..rr..")", 0)
	end
	return s
end
--Tx:027-06 03 00 03 00 02 35 BC
--Rx:028-06 03 04 00 01 00 01 1C F3
local function bcdEncode(s, x, y)
	print(bytes.tohex(string.sub(s, x, y)))
	s = {string.byte(s, x, y)}
	print(s)
	local rt = {}
	for i=1, #s do
		local t = s[i] - 0x33
		local h = xmath.shift(t, -4)
		h = xmath.xand(h, 0x0f)
		table.insert(rt, h + 0x30)
		table.insert(rt, xmath.xand(t, 0x0f) + 0x30)
	end
	return rt
end
local function ParseVoltageGetResponse(d, s, st)
	s = DLT645FrameChk(s, st, 18, 03, "读A项电压", " 读参数失败!!")
	s = bcdEncode(s, 15, 16)
	s = string.char(s[3], s[4], s[1], 46, s[2])
	d.UA = tonumber(s)
end
--总电量
local function ParseCurrentGetResponse(d, s, st)
	s = DLT645FrameChk(s, st, 19, 03, "读A项电流: ", " 读参数失败!!")
	s = bcdEncode(s, 15, 17)
	s = string.char(s[1], s[2], s[3], 46, s[4], s[5], s[6])
	d.CA = tonumber(s)
	return
end
--一般数据解析，数据错误抛出异常
--Tx:561-9B 03 00 61 00 06 89 EC
--Rx:562-9B 03 0C 00 00 00 00 09 0C 00 00 00 00 00 00 85 71
local function ParseTotalGetResponse(d, s, st)
	s = DLT645FrameChk(s, st, 20, 03, "读总电量: ", " 读参数失败!!")
	s = bcdEncode(s, 15, 18)
	print(s)
	s = string.char(s[7], s[8], s[5], s[6], 46, s[3], s[4], s[1], s[2])
	d.Total = tonumber(s)
end
local function calcs(s, l)
	local x = 0
	local ss = {string.byte(s, 1, l)}
	for i = 1, l do
		x = x + ss[i]
	end
	--return x
	return xmath.xand(x, 255)
end
--生成645 请求数据帧
local function Mk645Cmd(cmd)
	local addr = "000000000000" .. dev.addr()
	addr = string.sub(addr, string.len(addr) - 11)
	addr, _= bytes.hexparse(addr)
	local ss = "\x68" .. addr .. "\x68\x11\04"..cmd
	ss = ss .. string.char(calcs(ss, 14)) .."\x16"
	--local cc = string.char(tonumber(dev.addr())) .. cmd
	--local ss = cc .. bytes.mbcrc(cc)
	--print("MkRtuCmd ::::")
	print(bytes.tohex(ss))
	return ss
end
local function ReadStart(cnt, level)
	--o, cmd, level, guid, data, on
	cnt.addUart(Mk645Cmd("\x33\x34\x34\x35"), level, "varget_1", datactx, ParseVoltageGetResponse)
	cnt.addUart(Mk645Cmd("\x33\x34\x35\x35"), level, "varget_2", datactx, ParseCurrentGetResponse)
	cnt.addUart(Mk645Cmd("\x33\x33\x34\x33"), level, "varget_3", datactx, ParseTotalGetResponse)
	cnt.start(true)
end
local function calData()
	local o = {}
	return datactx
end
--begin 定时上报数据
--读取定时上报数据标记
local ReadAutoFlag = false
--06 03 01 00 00 07 04 43    06 03 0E 00 00 00 00 00 00 00 00 00 00 00 00 00 00 5D 24
local function readAutoData()
	ReadAutoFlag = true
	local errcb = (function(e)
		if ReadAutoFlag then
			ReadAutoFlag = false
			print("------------------------------")
			print(debug)
			print(debug.traceback())
			print(e)
			local cc = {}
			cc.eid = 001
			cc.msg = e
			pcall(dev.repstatus, cc, nil)
		end
	end)
	local cb = function()
		if ReadAutoFlag then
			ReadAutoFlag = false
			local cc = {}
			cc["df"] = "dtsd1352"
			pcall(dev.repstatus, cc, calData())
		end
	end
	xpcall(function()
		local cnt = taskGroup(cb, errcb)
		ReadStart(cnt, 100)
	end, errcb)
end

local function rpcVarGet(_, on)
	local errcb = (function(e)
		print("------------------------------")
		print(debug)
		print(debug.traceback())
		print(e)
		local cc = {}
		cc.eid = 001
		cc.msg = e
		pcall(on, cc, nil)
	end)
	local cb = function()
		local cc = {}
		cc["df"] = "dtsd1352"
		pcall(on, cc, calData())
	end
	xpcall(function()
		local cnt = taskGroup(cb, errcb)
		ReadStart(cnt, 10)
	end, errcb)
end

--init lua system
(function()
	dev.regapi("poll", function()
		--print("poll  ceck!!!!!")
	end)
	dev.regapi("autoup", readAutoData)
	--RpcVarGet
	dev.regapi("varget", rpcVarGet)

	readAutoData()
end)()

print("ht-ddzy422a ok")
