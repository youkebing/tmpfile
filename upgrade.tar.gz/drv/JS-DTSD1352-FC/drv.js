var console = require("console")
var dev = require("dev")
var bytes = require("bytes")

function printCallStack() {
}

var datactx = {}
var xpcall = function(h, exh) {
	try {
		h()
	} catch (error) {
		console.log("00000000000000000000000----------------")
		console.log(error.message)
		console.log(error.stack)
		printCallStack()
		exh(error.message)
	}
}
var pcall = function(h, p1, p2, p3) {
	try {
		h(p1, p2, p3)
	} catch (error) {
		console.log(error.stack)
		printCallStack()
	}
}
var nullFunc = function() {}

//任务组处理模块
var taskGroup = function(cb, errcb) {
	var o = {}
	var verrcb
	verrcb = function(er) {
		try {
			errcb(er)
			console.log(er)
		} catch (error) {
		}
		verrcb = nullFunc
		cb = nullFunc
	}
	var tasks = []
	o.addUart = function(cmd, level, guid, d, on) {
		var ccb;
		var oo = function(ctx, s, st) {
			try {
				on(d, s, st)
				ccb()
			} catch (error) {
				verrcb(error)
			}
		}
		tasks.push(function(cc) {
			ccb = cc
			dev.read({}, level, guid, cmd, oo)
		})
	}
//par ：true 表示并行  flase 表示顺序执行
	o.start = function(par) {
		var excute
		if (par) {
			var ii = 1
			var ccc = function() {
				ii = ii - 1
				if (ii == 0) {
					xpcall(cb, verrcb)
				}
			}
			excute = function() {
				for (i = 0; i < tasks.length; i++) {
					ii = ii + 1
					tasks[i](ccc)
				}
				ccc()
			}
		} else {
			excute = function(){
				if (tasks[1] == nil) {
					xpcall(cb, verrcb)
				}
				else {
					var task = tasks[1];
					tasks = tasks.slice(1)
					task(excute)
				}
			}
		}
		xpcall(excute, verrcb)
	}
	return o
}
var MkRtuCmd = function (cmd) {
	var cc = new Uint8Array(cmd.byteLength + 3)
	cc.set(cmd, 1)
	cc[0] = parseInt(dev.addr())
	var crc = bytes.mbcrc(cc.buffer, 0, cc.byteLength - 2)
	crc = new Uint8Array(crc)
	cc[cc.byteLength - 2] = crc[0]
	cc[cc.byteLength - 1] = crc[1]
	console.log(bytes.tohex(cc.buffer))
	return cc.buffer
}
//--校验rtu数据帧，错误抛出异常
//--s 待校验数据 st 状态 p1 数据长度, p2 应答类型 errmsg 错误消息
var MBRtuFrameChk = function(s, st, p1, p2, errh, errmsg) {
	//--print("s:", s)
	//--print("st", st)
	if (st != 0) {
		throw errh+s
	}
	var buf = new Uint8Array(s)
	if (buf.byteLength != p1) {
		throw errh + errmsg + " length err"
	}
	var crc = bytes.mbcrc(s, 0, s.byteLength - 2)
	crc = new Uint8Array(crc)
	if ((crc[0] != buf[p1 - 2]) || (crc[0] != buf[p1 - 2])) {
		throw errh+"数据CRC err!!"
	}
}
//	var h = string.char(tonumber(dev.addr()), p2, p1 - 5)
//	if string.len(s) ~= p1 or h ~= string.sub(s, 1, 3) then
//		error(errh..errmsg, 0)
//	end
//	if bytes.mbcrc(string.sub(s, 1, p1-2)) ~= string.sub(s, p1-1, p1) then
//		error(errh.."数据CRC err!!", 0)
//	end
//}
//--Tx:027-06 03 00 03 00 02 35 BC
//--Rx:028-06 03 04 00 01 00 01 1C F3
var ParsePtCtGetResponse = function (d, s, st) {
	MBRtuFrameChk(s, st, 9, 03, "读PT/CT", " 读参数失败!!")
	var buf = new Uint8Array(s)
	//local ss = {string.byte(s, 1, -1)}
	//--数据解析为大端模式
	var pt = (buf[3] * 256 + buf[4])
	var ct = (buf[5] * 256 + buf[6])
	if (pt < 1) {
		pt = 1
	}
	if (ct < 1 ) {
		ct = 1
	}
	d.PT = pt
	d.CT = ct
}
var ParseTotalGetResponse = function(d, s, st) {
	MBRtuFrameChk(s, st, 9, 03, "读总电量: ", " 读参数失败!!")
	//local ss = {string.byte(s, 1, -1)}
	var ss = new Uint8Array(s)
	d.Total = (ss[3] * 256 * 256 * 256 + ss[4] * 256 * 256 + ss[5] * 256 + ss[6])
}
//--一般数据解析，数据错误抛出异常
//--Tx:561-9B 03 00 61 00 06 89 EC
//--Rx:562-9B 03 0C 00 00 00 00 09 0C 00 00 00 00 00 00 85 71
var ParseNormalGetResponse = function(d, s, st) {
	MBRtuFrameChk(s, st, 17, 03, "读电压电流: ", "读参数失败!!")
	var ss = new Uint8Array(s)
	//--A 相电压
	d.UA = ss[3] * 256 + ss[4]
	//--B 相电压
	d.UB = ss[5] * 256 + ss[6]
	//--C 相电压
	d.UC = ss[7] * 256 + ss[8]
	//--UAB 线电压
	d.CA = ss[9] * 256 + ss[10]
	//--UBC 线电压
	d.CB = ss[11] * 256 + ss[12]
	//--UAC 线电压
	d.CC = ss[13] * 256 + ss[14]
}
//--一般数据解析，数据错误抛出异常
//--Tx:561-9B 03 00 61 00 06 89 EC
//--Rx:562-9B 03 0C 00 00 00 00 09 0C 00 00 00 00 00 00 85 71
var ParseNormalGetResponse2 = function(d, s, st) {
	MBRtuFrameChk(s, st, 13, 03, "读线电压: ", "读参数失败!!")
	var ss = new Uint8Array(s)
	//--频率
	d.Freq = ss[3] * 256 + ss[4]
	//--A 相电压
	d.UAB = ss[5] * 256 + ss[6]
	//--B 相电压
	d.UCB = ss[7] * 256 + ss[8]
	//--C 相电压
	d.UAC = ss[9] * 256 + ss[10]
}
var ReadStart = function(cnt, level) {
	////--o, cmd, level, guid, data, on
	//console.log("ss-------------")
	cnt.addUart(MkRtuCmd(new Uint8Array([0x03, 0x00, 0x8d, 0x00, 0x02])), level, "varget_1", datactx, ParsePtCtGetResponse)//ParsePtCtGetResponse)
	cnt.addUart(MkRtuCmd(new Uint8Array([0x03, 0x00, 0x00, 0x00, 0x02])), level, "varget_2", datactx, ParseTotalGetResponse)//ParseTotalGetResponse)
	cnt.addUart(MkRtuCmd(new Uint8Array([0x03, 0x00, 0x61, 0x00, 0x06])), level, "varget_3", datactx, ParseNormalGetResponse)//ParseNormalGetResponse)
	cnt.addUart(MkRtuCmd(new Uint8Array([0x03, 0x00, 0x77, 0x00, 0x04])), level, "varget_4", datactx, ParseNormalGetResponse2)//ParseNormalGetResponse2)
	//console.log("ss-------------???????????")
	cnt.start(true)
	//console.log("ss-------------1111")
}
var calData = function() {
	var o = {}
	//--pt ct
	var pt = datactx.PT
	var ct = datactx.CT
	o.PT = pt
	o.CT = ct
	//--total
	o.Total = Number(((datactx.Total * pt * ct) / 100).toFixed(2))
	//--
	//--A 相电压
	o.UA =  Number((datactx.UA * pt * 0.1).toFixed(2))
	//--B 相电压
	o.UB =  Number((datactx.UB * pt * 0.1).toFixed(2))
	//--C 相电压
	o.UC =  Number((datactx.UC * pt * 0.1).toFixed(2))
	//--UAB 线电压
	o.CA =  Number((datactx.CA * ct * 0.1).toFixed(2))
	//--UBC 线电压
	o.CB =  Number((datactx.CB * ct * 0.1).toFixed(2))
	//--UAC 线电压
	o.CC =  Number((datactx.CC * ct * 0.1).toFixed(2))
	//--
	o.Freq =  Number((datactx.Freq * 0.01).toFixed(2))
	//--A 相电压
	o.UAB =  Number((datactx.UAB * pt * 0.1).toFixed(2))
	//--B 相电压
	o.UCB =  Number((datactx.UCB * pt * 0.1).toFixed(2))
	//--C 相电压
	o.UAC =  Number((datactx.UAC * pt * 0.1).toFixed(2))
	return o
}
//--begin 定时上报数据
//--读取定时上报数据标记
var ReadAutoFlag = false
//--06 03 01 00 00 07 04 43    06 03 0E 00 00 00 00 00 00 00 00 00 00 00 00 00 00 5D 24
var readAutoData = function() {
	ReadAutoFlag = true
	var errcb = function(e) {
		if (ReadAutoFlag) {
			ReadAutoFlag = false
			console.log("------------------------------")
			//print(debug)
			//print(debug.traceback())
			console.log(e)
			var cc = {}
			cc.eid = 001
			cc.msg = e
			pcall(dev.repstatus, cc, null)
		}
	}
	var cb = function() {
		if (ReadAutoFlag) {
			ReadAutoFlag = false
			var cc = {}
			cc["df"] = "dtsd1352"
			pcall(dev.repstatus, cc,  calData())
		}
	}
	xpcall(function() {
		var cnt = taskGroup(cb, errcb)
		ReadStart(cnt, 100)
	}, errcb)
}
var rpcVarGet = function (d, on) {
	var errcb = function(e) {
		console.log("------------------------------")
		//console.log(debug)
		//console.log(debug.traceback())
		console.log(e)
		var cc = {}
		cc.eid = 001
		cc.msg = e
		pcall(on, cc, null)
		printCallStack()
	}
	var cb = function() {
		var cc = {}
		cc["df"] = "dtsd1352"
		pcall(on, cc, calData())
	}
	xpcall(function() {
		try {
			var cnt = taskGroup(cb, errcb)
			ReadStart(cnt, 10)
		} catch (error) {
			console.log("000000000000000000000000000000")
		}
	}, errcb)
}

dev.regapi("poll", function() {
	//
})
dev.regapi("autoup", readAutoData)
dev.regapi("varget", rpcVarGet)

console.log("驱动加载成功：：：    okkkkk!!!")